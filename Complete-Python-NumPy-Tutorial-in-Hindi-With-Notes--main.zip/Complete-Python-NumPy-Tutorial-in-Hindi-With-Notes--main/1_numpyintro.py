import numpy as np
print(np.__version__) 